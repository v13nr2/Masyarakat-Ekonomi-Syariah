#
# TABLE STRUCTURE FOR: mst_akun
#

DROP TABLE IF EXISTS `mst_akun`;

CREATE TABLE `mst_akun` (
  `id_akun` int(11) NOT NULL AUTO_INCREMENT,
  `id_tipe_akun` int(11) NOT NULL,
  `kode_akun` varchar(20) NOT NULL,
  `nama_akun` varchar(50) NOT NULL,
  `saldo_normal` varchar(1) NOT NULL,
  `lokasi` varchar(15) NOT NULL,
  `posisi` int(11) NOT NULL,
  `tgl_dibuat` datetime NOT NULL,
  `tgl_diubah` datetime NOT NULL,
  `aktif` varchar(1) NOT NULL,
  `company_id` int(11) NOT NULL,
  `id_parent` int(11) DEFAULT NULL,
  `is_parent` enum('0','1') DEFAULT '0',
  `level` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_akun`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('1', '1', '10', 'Aset Lancar', 'D', 'Neraca', '1', '2016-07-28 11:29:47', '2017-02-17 10:45:52', 'A', '1', '0', '0', '0');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('2', '1', '101', 'Kas', 'D', 'Neraca', '3', '2016-07-28 11:37:00', '2016-07-28 12:01:51', 'A', '1', '1', '1', '1');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('3', '1', '1010', 'Kas Kecil', 'K', 'Neraca', '1', '2016-08-26 09:37:02', '2016-08-26 09:37:02', 'A', '1', '2', '1', '2');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('4', '1', '1013', 'Kas Besar', 'K', 'Neraca', '2', '2016-08-26 09:37:19', '2017-02-22 23:52:19', 'A', '1', '2', '1', '2');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('5', '1', '102', 'Bank', 'K', 'Neraca', '3', '2017-02-20 10:30:50', '2017-02-20 10:30:50', 'A', '1', '1', '1', '1');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('6', '1', '1020', 'Bank Umum Syariah', 'K', 'Neraca', '3', '2017-02-20 10:30:50', '2017-02-20 10:30:50', 'A', '1', '5', '1', '2');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('7', '1', '10201', 'Bank Muamalat', 'K', 'Profit', '6', '2016-08-26 09:37:34', '2017-02-10 15:37:05', 'A', '1', '6', '1', '3');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('8', '1', '1021', 'Unit Usaha Syariah', 'D', 'Profit', '2', '2017-02-17 10:52:43', '2017-02-17 10:52:43', 'A', '1', '5', '1', '2');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('9', '1', '10211', 'Bank Cimb Niaga Syariah', 'D', 'Neraca', '1', '2017-03-03 15:37:07', '2017-03-23 15:48:14', 'A', '1', '8', '1', '3');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('10', '1', '1022', 'BMT/Koperasi Syariah', 'D', 'Neraca', '0', '2017-03-05 10:50:55', '2017-03-05 10:51:47', 'A', '1', '5', '1', '2');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('11', '1', '103', 'Investasi Jangka Pendek', 'D', 'Neraca', '0', '2017-03-05 18:28:44', '2017-03-05 18:28:44', 'A', '1', '1', '1', '1');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('12', '1', '1030', 'Deposito Syariah', 'D', 'Neraca', '0', '2017-03-17 13:46:17', '2017-03-17 13:46:17', 'A', '1', '11', '1', '2');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('13', '2', '20', 'Kewajiban Jangka Pendek', 'D', 'Neraca', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'A', '1', '0', '0', '0');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('14', '2', '201', 'Utang Kewajiban Sponsorship', 'D', 'Neraca', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'A', '1', '13', '1', '1');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('15', '2', '202', 'Utang Kewajiban Donasi', 'D', 'Neraca', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'A', '1', '13', '1', '1');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('16', '2', '203', 'Utang Kewajiban Hibah', 'D', 'Neraca', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'A', '1', '13', '1', '1');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('17', '2', '2010', 'Seminar', 'D', 'Neraca', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'A', '1', '14', '1', '2');
INSERT INTO `mst_akun` (`id_akun`, `id_tipe_akun`, `kode_akun`, `nama_akun`, `saldo_normal`, `lokasi`, `posisi`, `tgl_dibuat`, `tgl_diubah`, `aktif`, `company_id`, `id_parent`, `is_parent`, `level`) VALUES ('18', '1', '1012', 'Kas Contoh', 'D', 'Neraca', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'A', '0', '2', '1', '2');


#
# TABLE STRUCTURE FOR: mst_company
#

DROP TABLE IF EXISTS `mst_company`;

CREATE TABLE `mst_company` (
  `company_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(30) NOT NULL,
  `address` varchar(100) NOT NULL,
  `telp_anda` varchar(20) NOT NULL,
  `email_anda` varchar(50) NOT NULL,
  `tgl_daftar` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `kode_unik` varchar(20) NOT NULL,
  `tipe` varchar(10) NOT NULL,
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `mst_company` (`company_id`, `company_name`, `address`, `telp_anda`, `email_anda`, `tgl_daftar`, `kode_unik`, `tipe`) VALUES ('1', 'NAMA PERUSAHAAN', 'ALAMAT 1234', '089628704242', 'rafeldo@gmail.com', '2017-02-22 23:45:07', '6g5burs5sy04', 'Free');


#
# TABLE STRUCTURE FOR: mst_dokumen
#

DROP TABLE IF EXISTS `mst_dokumen`;

CREATE TABLE `mst_dokumen` (
  `dokumen_id` int(11) NOT NULL AUTO_INCREMENT,
  `dokumen_nama` varchar(100) DEFAULT NULL,
  `dokumen_keterangan` longtext,
  `dokumen_logo` varchar(100) DEFAULT NULL,
  `insert_user_id` int(11) DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `update_user_id` int(11) DEFAULT NULL,
  `update_timestamp` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`dokumen_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: mst_pengguna
#

DROP TABLE IF EXISTS `mst_pengguna`;

CREATE TABLE `mst_pengguna` (
  `id_pengguna` bigint(20) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `katasandi` varchar(60) NOT NULL,
  `dibuat` datetime NOT NULL,
  `terakhir` datetime NOT NULL,
  `company_id` int(11) NOT NULL,
  `koderahasia` varchar(20) NOT NULL,
  `verifikasi` varchar(1) NOT NULL,
  `link_url` varchar(50) NOT NULL,
  `status` varchar(1) NOT NULL,
  PRIMARY KEY (`id_pengguna`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `mst_pengguna` (`id_pengguna`, `nama`, `email`, `katasandi`, `dibuat`, `terakhir`, `company_id`, `koderahasia`, `verifikasi`, `link_url`, `status`) VALUES ('1', 'Fuck', 'admin@example.com', '81dc9bdb52d04dc20036dbd8313ed055', '2017-02-22 23:45:07', '2017-05-22 16:33:54', '1', '6g5burs5sy04', 'A', '', 'A');
INSERT INTO `mst_pengguna` (`id_pengguna`, `nama`, `email`, `katasandi`, `dibuat`, `terakhir`, `company_id`, `koderahasia`, `verifikasi`, `link_url`, `status`) VALUES ('2', 'admin1', 'admin1@gmail.com', '0192023a7bbd73250516f069df18b500', '2017-03-05 10:34:39', '2017-03-05 10:36:16', '1', '5sbjgeh8mj8c', 'A', '', 'A');
INSERT INTO `mst_pengguna` (`id_pengguna`, `nama`, `email`, `katasandi`, `dibuat`, `terakhir`, `company_id`, `koderahasia`, `verifikasi`, `link_url`, `status`) VALUES ('3', 'coba', 'coba@gmail.com', '0192023a7bbd73250516f069df18b500', '2017-03-05 10:36:29', '2017-03-05 10:36:29', '1', '573yzf36ngws', 'A', '', 'A');
INSERT INTO `mst_pengguna` (`id_pengguna`, `nama`, `email`, `katasandi`, `dibuat`, `terakhir`, `company_id`, `koderahasia`, `verifikasi`, `link_url`, `status`) VALUES ('4', 'rafeldo', 'rafeldo29@gmail.com', '7777bb4bfb029a24e4760b28f6f06d56', '2017-03-18 16:41:13', '2017-07-23 22:15:05', '1', '50a4x5mo65gk', 'A', '', 'A');
INSERT INTO `mst_pengguna` (`id_pengguna`, `nama`, `email`, `katasandi`, `dibuat`, `terakhir`, `company_id`, `koderahasia`, `verifikasi`, `link_url`, `status`) VALUES ('5', 'sulaiman', 'rafeldosulaiman3@gmail.com', '9a1c0d75ce2bec1835042cce7363fc1c', '2017-04-01 16:23:48', '2017-04-01 16:23:48', '1', '2szoavkj9dwk', 'A', '', 'A');


#
# TABLE STRUCTURE FOR: mst_rekening_bank
#

DROP TABLE IF EXISTS `mst_rekening_bank`;

CREATE TABLE `mst_rekening_bank` (
  `bank_id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_kode` varchar(10) DEFAULT NULL,
  `bank_nama` varchar(100) DEFAULT NULL,
  `bank_cabang` varchar(100) DEFAULT NULL,
  `bank_atas_nama` varchar(100) DEFAULT NULL,
  `bank_no_rek` varchar(100) DEFAULT NULL,
  `bank_jenis_tabungan` varchar(100) DEFAULT NULL,
  `insert_user_id` int(11) DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `update_user_id` int(11) DEFAULT NULL,
  `update_timestamp` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`bank_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: mst_tipeakun
#

DROP TABLE IF EXISTS `mst_tipeakun`;

CREATE TABLE `mst_tipeakun` (
  `id_tipe_akun` int(11) NOT NULL AUTO_INCREMENT,
  `kode_tipe_akun` varchar(2) NOT NULL,
  `nama_tipe_akun` varchar(30) NOT NULL,
  `keterangan` varchar(160) DEFAULT NULL,
  `tgl_dibuat` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tgl_diubah` datetime NOT NULL,
  PRIMARY KEY (`id_tipe_akun`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `mst_tipeakun` (`id_tipe_akun`, `kode_tipe_akun`, `nama_tipe_akun`, `keterangan`, `tgl_dibuat`, `tgl_diubah`) VALUES ('1', '1', 'Aset', NULL, '2017-07-20 22:37:46', '2016-07-19 15:51:48');
INSERT INTO `mst_tipeakun` (`id_tipe_akun`, `kode_tipe_akun`, `nama_tipe_akun`, `keterangan`, `tgl_dibuat`, `tgl_diubah`) VALUES ('2', '2', 'Kewajiban', NULL, '2017-07-20 22:37:49', '2016-07-19 15:51:48');
INSERT INTO `mst_tipeakun` (`id_tipe_akun`, `kode_tipe_akun`, `nama_tipe_akun`, `keterangan`, `tgl_dibuat`, `tgl_diubah`) VALUES ('3', '3', 'Aset Neto', NULL, '2017-07-20 22:37:56', '2016-07-19 15:51:52');
INSERT INTO `mst_tipeakun` (`id_tipe_akun`, `kode_tipe_akun`, `nama_tipe_akun`, `keterangan`, `tgl_dibuat`, `tgl_diubah`) VALUES ('4', '4', 'Penerimaan', NULL, '2017-07-20 22:38:02', '2016-07-19 15:51:48');
INSERT INTO `mst_tipeakun` (`id_tipe_akun`, `kode_tipe_akun`, `nama_tipe_akun`, `keterangan`, `tgl_dibuat`, `tgl_diubah`) VALUES ('5', '5', 'Pengeluaran', NULL, '2017-07-20 22:38:05', '2016-07-19 15:51:48');


#
# TABLE STRUCTURE FOR: mst_transaksi_akun
#

DROP TABLE IF EXISTS `mst_transaksi_akun`;

CREATE TABLE `mst_transaksi_akun` (
  `id_transaksi_akun` int(11) NOT NULL AUTO_INCREMENT,
  `nama_transaksi_akun` varchar(50) NOT NULL,
  `tgl_dibuat` datetime NOT NULL,
  `tgl_diubah` datetime NOT NULL,
  `aktif` varchar(1) NOT NULL,
  PRIMARY KEY (`id_transaksi_akun`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: ref_kabupaten
#

DROP TABLE IF EXISTS `ref_kabupaten`;

CREATE TABLE `ref_kabupaten` (
  `kabupaten_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `kabupaten_prov_id` int(11) unsigned NOT NULL,
  `kabupaten_nama` varchar(100) DEFAULT NULL,
  `kabupaten_kode` varchar(10) DEFAULT NULL,
  `insert_user_id` bigint(20) DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT NULL,
  `update_user_id` bigint(20) DEFAULT NULL,
  `update_timestamp` datetime DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`kabupaten_id`),
  UNIQUE KEY `unique_index` (`kabupaten_prov_id`,`kabupaten_nama`)
) ENGINE=InnoDB AUTO_INCREMENT=506 DEFAULT CHARSET=latin1;

INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('7', '1', 'Kabupaten Aceh Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('8', '1', 'Kabupaten Aceh Barat Daya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('9', '1', 'Kabupaten Aceh Besar', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('10', '1', 'Kabupaten Aceh Jaya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('11', '1', 'Kabupaten Aceh Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('12', '1', 'Kabupaten Aceh Singkil', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('13', '1', 'Kabupaten Aceh Tamiang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('14', '1', 'Kabupaten Aceh Tengah', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('15', '1', 'Kabupaten Aceh Tenggara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('16', '1', 'Kabupaten Aceh Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('17', '1', 'Kabupaten Aceh Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('18', '1', 'Kabupaten Bener Meriah', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('19', '1', 'Kabupaten Bireuen', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('20', '1', 'Kabupaten Gayo Lues', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('21', '1', 'Kabupaten Nagan Raya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('22', '1', 'Kabupaten Pidie', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('23', '1', 'Kabupaten Pidie Jaya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('24', '1', 'Kabupaten Simeulue', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('25', '1', 'Kota Banda Aceh', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('26', '1', 'Kota Langsa', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('27', '1', 'Kota Lhokseumawe', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('28', '1', 'Kota Sabang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('29', '1', 'Kota Subulussalam', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('30', '2', 'Kabupaten Asahan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('31', '2', 'Kabupaten Batu Bara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('32', '2', 'Kabupaten Dairi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('33', '2', 'Kabupaten Deli Serdang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('34', '2', 'Kabupaten Humbang Hasundutan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('35', '2', 'Kabupaten Karo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('36', '2', 'Kabupaten Labuhanbatu', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('37', '2', 'Kabupaten Labuhanbatu Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('38', '2', 'Kabupaten Labuhanbatu Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('39', '2', 'Kabupaten Langkat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('40', '2', 'Kabupaten Mandailing Natal', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('41', '2', 'Kabupaten Nias', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('42', '2', 'Kabupaten Nias Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('43', '2', 'Kabupaten Nias Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('44', '2', 'Kabupaten Nias Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('45', '2', 'Kabupaten Padang Lawas', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('46', '2', 'Kabupaten Padang Lawas Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('47', '2', 'Kabupaten Pakpak Bharat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('48', '2', 'Kabupaten Samosir', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('49', '2', 'Kabupaten Serdang Bedagai', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('50', '2', 'Kabupaten Simalungun', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('51', '2', 'Kabupaten Tapanuli Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('52', '2', 'Kabupaten Tapanuli Tengah', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('53', '2', 'Kabupaten Tapanuli Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('54', '2', 'Kabupaten Toba Samosir', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('55', '2', 'Kota Binjai', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('56', '2', 'Kota Gunung Sitoli', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('57', '2', 'Kota Medan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('58', '2', 'Kota Padang Sidempuan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('59', '2', 'Kota Pematangsiantar', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('60', '2', 'Kota Sibolga', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('61', '2', 'Kota Tanjung Balai', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('62', '2', 'Kota Tebing Tinggi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('63', '3', 'Kabupaten Bengkulu Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('64', '3', 'Kabupaten Bengkulu Tengah', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('65', '3', 'Kabupaten Bengkulu Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('66', '3', 'Kabupaten Benteng', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('67', '3', 'Kabupaten Kaur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('68', '3', 'Kabupaten Kepahiang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('69', '3', 'Kabupaten Lebong', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('70', '3', 'Kabupaten Mukomuko', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('71', '3', 'Kabupaten Rejang Lebong', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('72', '3', 'Kabupaten Seluma', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('73', '3', 'Kota Bengkulu', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('74', '4', 'Kabupaten Batang Hari', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('75', '4', 'Kabupaten Bungo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('76', '4', 'Kabupaten Kerinci', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('77', '4', 'Kabupaten Merangin', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('78', '4', 'Kabupaten Muaro Jambi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('79', '4', 'Kabupaten Sarolangun', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('80', '4', 'Kabupaten Tanjung Jabung Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('81', '4', 'Kabupaten Tanjung Jabung Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('82', '4', 'Kabupaten Tebo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('83', '4', 'Kota Jambi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('84', '4', 'Kota Sungai Penuh', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('85', '5', 'Kabupaten Bengkalis', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('86', '5', 'Kabupaten Indragiri Hilir', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('87', '5', 'Kabupaten Indragiri Hulu', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('88', '5', 'Kabupaten Kampar', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('89', '5', 'Kabupaten Kuantan Singingi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('90', '5', 'Kabupaten Pelalawan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('91', '5', 'Kabupaten Rokan Hilir', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('92', '5', 'Kabupaten Rokan Hulu', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('93', '5', 'Kabupaten Siak', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('94', '5', 'Kota Pekanbaru', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('95', '5', 'Kota Dumai', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('96', '5', 'Kabupaten Kepulauan Meranti', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('97', '6', 'Kabupaten Agam', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('98', '6', 'Kabupaten Dharmasraya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('99', '6', 'Kabupaten Kepulauan Mentawai', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('100', '6', 'Kabupaten Lima Puluh Kota', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('101', '6', 'Kabupaten Padang Pariaman', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('102', '6', 'Kabupaten Pasaman', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('103', '6', 'Kabupaten Pasaman Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('104', '6', 'Kabupaten Pesisir Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('105', '6', 'Kabupaten Sijunjung', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('106', '6', 'Kabupaten Solok', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('107', '6', 'Kabupaten Solok Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('108', '6', 'Kabupaten Tanah Datar', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('109', '6', 'Kota Bukittinggi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('110', '6', 'Kota Padang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('111', '6', 'Kota Padangpanjang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('112', '6', 'Kota Pariaman', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('113', '6', 'Kota Payakumbuh', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('114', '6', 'Kota Sawahlunto', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('115', '6', 'Kota Solok', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('116', '7', 'Kabupaten Banyuasin', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('117', '7', 'Kabupaten Empat Lawang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('118', '7', 'Kabupaten Lahat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('119', '7', 'Kabupaten Muara Enim', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('120', '7', 'Kabupaten Musi Banyuasin', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('121', '7', 'Kabupaten Musi Rawas', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('122', '7', 'Kabupaten Ogan Ilir', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('123', '7', 'Kabupaten Ogan Komering Ilir', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('124', '7', 'Kabupaten Ogan Komering Ulu', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('125', '7', 'Kabupaten Ogan Komering Ulu Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('126', '7', 'Kabupaten Ogan Komering Ulu Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('127', '7', 'Kota Lubuklinggau', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('128', '7', 'Kota Pagar Alam', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('129', '7', 'Kota Palembang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('130', '7', 'Kota Prabumulih', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('131', '8', 'Kabupaten Lampung Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('132', '8', 'Kabupaten Lampung Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('133', '8', 'Kabupaten Lampung Tengah', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('134', '8', 'Kabupaten Lampung Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('135', '8', 'Kabupaten Lampung Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('136', '8', 'Kabupaten Mesuji', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('137', '8', 'Kabupaten Pesawaran', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('138', '8', 'Kabupaten Pringsewu', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('139', '8', 'Kabupaten Tanggamus', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('140', '8', 'Kabupaten Tulang Bawang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('141', '8', 'Kabupaten Tulang Bawang Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('142', '8', 'Kabupaten Way Kanan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('143', '8', 'Kota Bandar Lampung', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('144', '8', 'Kota Metro', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('145', '9', 'Kabupaten Bangka', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('146', '9', 'Kabupaten Bangka Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('147', '9', 'Kabupaten Bangka Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('148', '9', 'Kabupaten Bangka Tengah', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('149', '9', 'Kabupaten Belitung', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('150', '9', 'Kabupaten Belitung Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('151', '9', 'Kota Pangkal Pinang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('152', '10', 'Kabupaten Bintan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('153', '10', 'Kabupaten Karimun', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('154', '10', 'Kabupaten Kepulauan Anambas', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('155', '10', 'Kabupaten Lingga', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('156', '10', 'Kabupaten Natuna', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('157', '10', 'Kota Batam', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('158', '10', 'Kota Tanjung Pinang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('159', '11', 'Kabupaten Lebak', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('160', '11', 'Kabupaten Pandeglang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('161', '11', 'Kabupaten Serang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('162', '11', 'Kabupaten Tangerang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('163', '11', 'Kota Cilegon', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('164', '11', 'Kota Serang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('165', '11', 'Kota Tangerang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('166', '11', 'Kota Tangerang Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('167', '12', 'Kabupaten Bandung', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('168', '12', 'Kabupaten Bandung Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('169', '12', 'Kabupaten Bekasi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('170', '12', 'Kabupaten Bogor', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('171', '12', 'Kabupaten Ciamis', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('172', '12', 'Kabupaten Cianjur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('173', '12', 'Kabupaten Cirebon', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('174', '12', 'Kabupaten Garut', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('175', '12', 'Kabupaten Indramayu', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('176', '12', 'Kabupaten Karawang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('177', '12', 'Kabupaten Kuningan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('178', '12', 'Kabupaten Majalengka', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('179', '12', 'Kabupaten Purwakarta', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('180', '12', 'Kabupaten Subang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('181', '12', 'Kabupaten Sukabumi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('182', '12', 'Kabupaten Sumedang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('183', '12', 'Kabupaten Tasikmalaya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('184', '12', 'Kota Bandung', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('185', '12', 'Kota Banjar', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('186', '12', 'Kota Bekasi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('187', '12', 'Kota Bogor', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('188', '12', 'Kota Cimahi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('189', '12', 'Kota Cirebon', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('190', '12', 'Kota Depok', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('191', '12', 'Kota Sukabumi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('192', '12', 'Kota Tasikmalaya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('193', '13', 'Kabupaten Administrasi Kepulauan Seribu', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('194', '13', 'Kota Administrasi Jakarta Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('195', '13', 'Kota Administrasi Jakarta Pusat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('196', '13', 'Kota Administrasi Jakarta Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('197', '13', 'Kota Administrasi Jakarta Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('198', '13', 'Kota Administrasi Jakarta Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('199', '14', 'Kabupaten Banjarnegara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('200', '14', 'Kabupaten Banyumas', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('201', '14', 'Kabupaten Batang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('202', '14', 'Kabupaten Blora', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('203', '14', 'Kabupaten Boyolali', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('204', '14', 'Kabupaten Brebes', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('205', '14', 'Kabupaten Cilacap', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('206', '14', 'Kabupaten Demak', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('207', '14', 'Kabupaten Grobogan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('208', '14', 'Kabupaten Jepara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('209', '14', 'Kabupaten Karanganyar', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('210', '14', 'Kabupaten Kebumen', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('211', '14', 'Kabupaten Kendal', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('212', '14', 'Kabupaten Klaten', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('213', '14', 'Kabupaten Kudus', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('214', '14', 'Kabupaten Magelang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('215', '14', 'Kabupaten Pati', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('216', '14', 'Kabupaten Pekalongan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('217', '14', 'Kabupaten Pemalang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('218', '14', 'Kabupaten Purbalingga', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('219', '14', 'Kabupaten Purworejo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('220', '14', 'Kabupaten Rembang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('221', '14', 'Kabupaten Semarang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('222', '14', 'Kabupaten Sragen', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('223', '14', 'Kabupaten Sukoharjo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('224', '14', 'Kabupaten Tegal', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('225', '14', 'Kabupaten Temanggung', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('226', '14', 'Kabupaten Wonogiri', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('227', '14', 'Kabupaten Wonosobo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('228', '14', 'Kota Magelang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('229', '14', 'Kota Pekalongan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('230', '14', 'Kota Salatiga', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('231', '14', 'Kota Semarang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('232', '14', 'Kota Surakarta', '', '6', '2017-07-17 20:15:10', NULL, NULL, '1');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('233', '14', 'Kota Tegal', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('234', '15', 'Kabupaten Bangkalan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('235', '15', 'Kabupaten Banyuwangi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('236', '15', 'Kabupaten Blitar', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('237', '15', 'Kabupaten Bojonegoro', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('238', '15', 'Kabupaten Bondowoso', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('239', '15', 'Kabupaten Gresik', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('240', '15', 'Kabupaten Jember', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('241', '15', 'Kabupaten Jombang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('242', '15', 'Kabupaten Kediri', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('243', '15', 'Kabupaten Lamongan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('244', '15', 'Kabupaten Lumajang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('245', '15', 'Kabupaten Madiun', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('246', '15', 'Kabupaten Magetan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('247', '15', 'Kabupaten Malang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('248', '15', 'Kabupaten Mojokerto', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('249', '15', 'Kabupaten Nganjuk', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('250', '15', 'Kabupaten Ngawi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('251', '15', 'Kabupaten Pacitan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('252', '15', 'Kabupaten Pamekasan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('253', '15', 'Kabupaten Pasuruan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('254', '15', 'Kabupaten Ponorogo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('255', '15', 'Kabupaten Probolinggo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('256', '15', 'Kabupaten Sampang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('257', '15', 'Kabupaten Sidoarjo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('258', '15', 'Kabupaten Situbondo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('259', '15', 'Kabupaten Sumenep', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('260', '15', 'Kabupaten Trenggalek', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('261', '15', 'Kabupaten Tuban', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('262', '15', 'Kabupaten Tulungagung', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('263', '15', 'Kota Batu', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('264', '15', 'Kota Blitar', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('265', '15', 'Kota Kediri', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('266', '15', 'Kota Madiun', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('267', '15', 'Kota Malang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('268', '15', 'Kota Mojokerto', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('269', '15', 'Kota Pasuruan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('270', '15', 'Kota Probolinggo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('271', '15', 'Kota Surabaya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('272', '16', 'Kabupaten Bantul', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('273', '16', 'Kabupaten Gunung Kidul', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('274', '16', 'Kabupaten Kulon Progo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('275', '16', 'Kabupaten Sleman', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('276', '16', 'Kota Yogyakarta', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('277', '17', 'Kabupaten Badung', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('278', '17', 'Kabupaten Bangli', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('279', '17', 'Kabupaten Buleleng', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('280', '17', 'Kabupaten Gianyar', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('281', '17', 'Kabupaten Jembrana', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('282', '17', 'Kabupaten Karangasem', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('283', '17', 'Kabupaten Klungkung', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('284', '17', 'Kabupaten Tabanan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('285', '17', 'Kota Denpasar', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('286', '18', 'Kabupaten Bima', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('287', '18', 'Kabupaten Dompu', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('288', '18', 'Kabupaten Lombok Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('289', '18', 'Kabupaten Lombok Tengah', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('290', '18', 'Kabupaten Lombok Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('291', '18', 'Kabupaten Lombok Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('292', '18', 'Kabupaten Sumbawa', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('293', '18', 'Kabupaten Sumbawa Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('294', '18', 'Kota Bima', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('295', '18', 'Kota Mataram', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('296', '19', 'Kabupaten Kupang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('297', '19', 'Kabupaten Timor Tengah Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('298', '19', 'Kabupaten Timor Tengah Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('299', '19', 'Kabupaten Belu', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('300', '19', 'Kabupaten Alor', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('301', '19', 'Kabupaten Flores Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('302', '19', 'Kabupaten Sikka', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('303', '19', 'Kabupaten Ende', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('304', '19', 'Kabupaten Ngada', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('305', '19', 'Kabupaten Manggarai', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('306', '19', 'Kabupaten Sumba Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('307', '19', 'Kabupaten Sumba Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('308', '19', 'Kabupaten Lembata', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('309', '19', 'Kabupaten Rote Ndao', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('310', '19', 'Kabupaten Manggarai Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('311', '19', 'Kabupaten Nagekeo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('312', '19', 'Kabupaten Sumba Tengah', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('313', '19', 'Kabupaten Sumba Barat Daya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('314', '19', 'Kabupaten Manggarai Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('315', '19', 'Kabupaten Sabu Raijua', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('316', '19', 'Kota Kupang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('317', '20', 'Kabupaten Bengkayang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('318', '20', 'Kabupaten Kapuas Hulu', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('319', '20', 'Kabupaten Kayong Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('320', '20', 'Kabupaten Ketapang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('321', '20', 'Kabupaten Kubu Raya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('322', '20', 'Kabupaten Landak', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('323', '20', 'Kabupaten Melawi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('324', '20', 'Kabupaten Pontianak', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('325', '20', 'Kabupaten Sambas', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('326', '20', 'Kabupaten Sanggau', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('327', '20', 'Kabupaten Sekadau', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('328', '20', 'Kabupaten Sintang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('329', '20', 'Kota Pontianak', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('330', '20', 'Kota Singkawang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('331', '21', 'Kabupaten Balangan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('332', '21', 'Kabupaten Banjar', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('333', '21', 'Kabupaten Barito Kuala', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('334', '21', 'Kabupaten Hulu Sungai Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('335', '21', 'Kabupaten Hulu Sungai Tengah', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('336', '21', 'Kabupaten Hulu Sungai Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('337', '21', 'Kabupaten Kotabaru', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('338', '21', 'Kabupaten Tabalong', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('339', '21', 'Kabupaten Tanah Bumbu', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('340', '21', 'Kabupaten Tanah Laut', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('341', '21', 'Kabupaten Tapin', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('342', '21', 'Kota Banjarbaru', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('343', '21', 'Kota Banjarmasin', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('344', '22', 'Kabupaten Barito Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('345', '22', 'Kabupaten Barito Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('346', '22', 'Kabupaten Barito Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('347', '22', 'Kabupaten Gunung Mas', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('348', '22', 'Kabupaten Kapuas', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('349', '22', 'Kabupaten Katingan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('350', '22', 'Kabupaten Kotawaringin Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('351', '22', 'Kabupaten Kotawaringin Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('352', '22', 'Kabupaten Lamandau', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('353', '22', 'Kabupaten Murung Raya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('354', '22', 'Kabupaten Pulang Pisau', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('355', '22', 'Kabupaten Sukamara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('356', '22', 'Kabupaten Seruyan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('357', '22', 'Kota Palangka Raya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('358', '23', 'Kabupaten Berau', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('359', '23', 'Kabupaten Bulungan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('360', '23', 'Kabupaten Kutai Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('361', '23', 'Kabupaten Kutai Kartanegara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('362', '23', 'Kabupaten Kutai Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('363', '23', 'Kabupaten Malinau', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('364', '23', 'Kabupaten Nunukan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('365', '23', 'Kabupaten Paser', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('366', '23', 'Kabupaten Penajam Paser Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('367', '23', 'Kabupaten Tana Tidung', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('368', '23', 'Kota Balikpapan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('369', '23', 'Kota Bontang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('370', '23', 'Kota Samarinda', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('371', '23', 'Kota Tarakan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('372', '24', 'Kabupaten Boalemo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('373', '24', 'Kabupaten Bone Bolango', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('374', '24', 'Kabupaten Gorontalo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('375', '24', 'Kabupaten Gorontalo Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('376', '24', 'Kabupaten Pohuwato', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('377', '24', 'Kota Gorontalo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('378', '25', 'Kabupaten Bantaeng', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('379', '25', 'Kabupaten Barru', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('380', '25', 'Kabupaten Bone', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('381', '25', 'Kabupaten Bulukumba', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('382', '25', 'Kabupaten Enrekang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('383', '25', 'Kabupaten Gowa', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('384', '25', 'Kabupaten Jeneponto', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('385', '25', 'Kabupaten Kepulauan Selayar', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('386', '25', 'Kabupaten Luwu', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('387', '25', 'Kabupaten Luwu Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('388', '25', 'Kabupaten Luwu Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('389', '25', 'Kabupaten Maros', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('390', '25', 'Kabupaten Pangkajene dan Kepulauan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('391', '25', 'Kabupaten Pinrang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('392', '25', 'Kabupaten Sidenreng Rappang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('393', '25', 'Kabupaten Sinjai', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('394', '25', 'Kabupaten Soppeng', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('395', '25', 'Kabupaten Takalar', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('396', '25', 'Kabupaten Tana Toraja', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('397', '25', 'Kabupaten Toraja Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('398', '25', 'Kabupaten Wajo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('399', '25', 'Kota Makassar', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('400', '25', 'Kota Palopo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('401', '25', 'Kota Parepare', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('402', '26', 'Kabupaten Bombana', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('403', '26', 'Kabupaten Buton', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('404', '26', 'Kabupaten Buton Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('405', '26', 'Kabupaten Kolaka', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('406', '26', 'Kabupaten Kolaka Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('407', '26', 'Kabupaten Konawe', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('408', '26', 'Kabupaten Konawe Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('409', '26', 'Kabupaten Konawe Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('410', '26', 'Kabupaten Muna', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('411', '26', 'Kabupaten Wakatobi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('412', '26', 'Kota Bau-Bau', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('413', '26', 'Kota Kendari', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('414', '27', 'Kabupaten Banggai', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('415', '27', 'Kabupaten Banggai Kepulauan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('416', '27', 'Kabupaten Buol', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('417', '27', 'Kabupaten Donggala', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('418', '27', 'Kabupaten Morowali', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('419', '27', 'Kabupaten Parigi Moutong', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('420', '27', 'Kabupaten Poso', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('421', '27', 'Kabupaten Tojo Una-Una', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('422', '27', 'Kabupaten Toli-Toli', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('423', '27', 'Kabupaten Sigi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('424', '27', 'Kota Palu', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('425', '28', 'Kabupaten Bolaang Mongondow', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('426', '28', 'Kabupaten Bolaang Mongondow Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('427', '28', 'Kabupaten Bolaang Mongondow Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('428', '28', 'Kabupaten Bolaang Mongondow Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('429', '28', 'Kabupaten Kepulauan Sangihe', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('430', '28', 'Kabupaten Kepulauan Siau Tagulandang Biaro', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('431', '28', 'Kabupaten Kepulauan Talaud', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('432', '28', 'Kabupaten Minahasa', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('433', '28', 'Kabupaten Minahasa Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('434', '28', 'Kabupaten Minahasa Tenggara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('435', '28', 'Kabupaten Minahasa Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('436', '28', 'Kota Bitung', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('437', '28', 'Kota Kotamobagu', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('438', '28', 'Kota Manado', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('439', '28', 'Kota Tomohon', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('440', '29', 'Kabupaten Majene', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('441', '29', 'Kabupaten Mamasa', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('442', '29', 'Kabupaten Mamuju', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('443', '29', 'Kabupaten Mamuju Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('444', '29', 'Kabupaten Polewali Mandar', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('445', '30', 'Kabupaten Buru', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('446', '30', 'Kabupaten Buru Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('447', '30', 'Kabupaten Kepulauan Aru', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('448', '30', 'Kabupaten Maluku Barat Daya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('449', '30', 'Kabupaten Maluku Tengah', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('450', '30', 'Kabupaten Maluku Tenggara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('451', '30', 'Kabupaten Maluku Tenggara Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('452', '30', 'Kabupaten Seram Bagian Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('453', '30', 'Kabupaten Seram Bagian Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('454', '30', 'Kota Ambon', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('455', '30', 'Kota Tual', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('456', '31', 'Kabupaten Halmahera Barat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('457', '31', 'Kabupaten Halmahera Tengah', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('458', '31', 'Kabupaten Halmahera Utara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('459', '31', 'Kabupaten Halmahera Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('460', '31', 'Kabupaten Kepulauan Sula', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('461', '31', 'Kabupaten Halmahera Timur', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('462', '31', 'Kabupaten Pulau Morotai', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('463', '31', 'Kota Ternate', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('464', '31', 'Kota Tidore Kepulauan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('465', '32', 'Kabupaten Asmat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('466', '32', 'Kabupaten Biak Numfor', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('467', '32', 'Kabupaten Boven Digoel', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('468', '32', 'Kabupaten Deiyai', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('469', '32', 'Kabupaten Dogiyai', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('470', '32', 'Kabupaten Intan Jaya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('471', '32', 'Kabupaten Jayapura', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('472', '32', 'Kabupaten Jayawijaya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('473', '32', 'Kabupaten Keerom', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('474', '32', 'Kabupaten Kepulauan Yapen', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('475', '32', 'Kabupaten Lanny Jaya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('476', '32', 'Kabupaten Mamberamo Raya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('477', '32', 'Kabupaten Mamberamo Tengah', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('478', '32', 'Kabupaten Mappi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('479', '32', 'Kabupaten Merauke', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('480', '32', 'Kabupaten Mimika', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('481', '32', 'Kabupaten Nabire', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('482', '32', 'Kabupaten Nduga', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('483', '32', 'Kabupaten Paniai', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('484', '32', 'Kabupaten Pegunungan Bintang', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('485', '32', 'Kabupaten Puncak', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('486', '32', 'Kabupaten Puncak Jaya', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('487', '32', 'Kabupaten Sarmi', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('488', '32', 'Kabupaten Supiori', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('489', '32', 'Kabupaten Tolikara', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('490', '32', 'Kabupaten Waropen', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('491', '32', 'Kabupaten Yahukimo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('492', '32', 'Kabupaten Yalimo', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('493', '32', 'Kota Jayapura', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('494', '33', 'Kabupaten Fakfak', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('495', '33', 'Kabupaten Kaimana', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('496', '33', 'Kabupaten Manokwari', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('497', '33', 'Kabupaten Maybrat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('498', '33', 'Kabupaten Raja Ampat', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('499', '33', 'Kabupaten Sorong', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('500', '33', 'Kabupaten Sorong Selatan', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('501', '33', 'Kabupaten Tambrauw', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('502', '33', 'Kabupaten Teluk Bintuni', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('503', '33', 'Kabupaten Teluk Wondama', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('504', '33', 'Kota Sorong', '', '6', '2017-07-17 20:15:10', NULL, NULL, '0');
INSERT INTO `ref_kabupaten` (`kabupaten_id`, `kabupaten_prov_id`, `kabupaten_nama`, `kabupaten_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('505', '9', 'Kabupaten Pangkal Pinang', '', '147', '2017-07-17 20:15:10', NULL, NULL, '0');


#
# TABLE STRUCTURE FOR: ref_provinsi
#

DROP TABLE IF EXISTS `ref_provinsi`;

CREATE TABLE `ref_provinsi` (
  `prov_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `prov_nama` varchar(100) DEFAULT NULL,
  `prov_kode` varchar(10) DEFAULT NULL,
  `insert_user_id` bigint(20) DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT NULL,
  `update_user_id` bigint(20) DEFAULT NULL,
  `update_timestamp` datetime DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`prov_id`),
  UNIQUE KEY `prop_name` (`prov_nama`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('1', 'Aceh', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('2', 'Sumatera Utara', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('3', 'Bengkulu', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('4', 'Jambi', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('5', 'Riau', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('6', 'Sumatera Barat', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('7', 'Sumatera Selatan', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('8', 'Lampung', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('9', 'Kepulauan Bangka Belitung', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('10', 'Kepulauan Riau', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('11', 'Banten', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('12', 'Jawa Barat', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('13', 'DKI Jakarta', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('14', 'Jawa Tengah', '', '1', '2017-07-17 20:10:20', NULL, NULL, '1');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('15', 'Jawa Timur', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('16', 'Daerah Istimewa Yogyakarta', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('17', 'Bali', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('18', 'Nusa Tenggara Barat', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('19', 'Nusa Tenggara Timur', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('20', 'Kalimantan Barat', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('21', 'Kalimantan Selatan', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('22', 'Kalimantan Tengah', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('23', 'Kalimantan Timur', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('24', 'Gorontalo', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('25', 'Sulawesi Selatan', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('26', 'Sulawesi Tenggara', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('27', 'Sulawesi Tengah', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('28', 'Sulawesi Utara', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('29', 'Sulawesi Barat', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('30', 'Maluku', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('31', 'Maluku Utara', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('32', 'Papua', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');
INSERT INTO `ref_provinsi` (`prov_id`, `prov_nama`, `prov_kode`, `insert_user_id`, `insert_timestamp`, `update_user_id`, `update_timestamp`, `is_default`) VALUES ('33', 'Papua Barat', '', '1', '2017-07-17 20:10:20', NULL, NULL, '0');


#
# TABLE STRUCTURE FOR: settings
#

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `setting_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `setting_value` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `setting_name` (`setting_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('accepted_file_formats', 'jpg,jpeg,doc', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('allow_partial_invoice_payment_from_clients', '1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('allowed_ip_addresses', '', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('app_title', 'Aplikasi Project Management', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('company_address', 'bla-bla', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('company_email', 'rafeldo29@gmail.com', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('company_name', 'Ramindo', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('company_phone', '83812602627', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('company_website', 'ramindo.com', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('currency_position', 'left', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('currency_symbol', 'Rp. ', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('date_format', 'Y-m-d', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('decimal_separator', ',', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('default_currency', 'IDR', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('email_protocol', '', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('email_sent_from_address', '', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('email_sent_from_name', '', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('email_smtp_host', '', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('email_smtp_pass', '', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('email_smtp_port', '', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('email_smtp_security_type', 'tls', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('email_smtp_user', '', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('first_day_of_week', '0', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('invoice_color', '', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('invoice_footer', '<p><br></p>', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('invoice_logo', '_file591546cd9f915-invoice-logo.png', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('invoice_prefix', '', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('invoice_style', 'style_1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('language', 'english', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('module_announcement', '1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('module_attendance', '1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('module_estimate', '1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('module_estimate_request', '1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('module_event', '1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('module_expense', '1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('module_help', '1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('module_invoice', '1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('module_knowledge_base', '1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('module_leave', '1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('module_message', '1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('module_note', '1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('module_project_timesheet', '1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('module_ticket', '1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('module_timeline', '1', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('rows_per_page', '10', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('scrollbar', 'jquery', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('send_bcc_to', '', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('show_background_image_in_signin_page', 'yes', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('show_logo_in_signin_page', 'yes', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('site_logo', '_file593e4915c6fc2-site-logo.png', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('time_format', '24_hours', '0');
INSERT INTO `settings` (`setting_name`, `setting_value`, `deleted`) VALUES ('timezone', 'Asia/Jakarta', '0');


#
# TABLE STRUCTURE FOR: tbl_donatur
#

DROP TABLE IF EXISTS `tbl_donatur`;

CREATE TABLE `tbl_donatur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(250) NOT NULL,
  `hp` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `id_kategori_penyedia_dana` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_donatur` (`id`, `nama`, `alamat`, `hp`, `email`, `id_kategori_penyedia_dana`) VALUES ('1', 'JLC', 'Tangerang', '098234343311', 'tangerang@gmail.com', '0');
INSERT INTO `tbl_donatur` (`id`, `nama`, `alamat`, `hp`, `email`, `id_kategori_penyedia_dana`) VALUES ('2', 'Jogjaide', 'Makassar', '0123121111', 'nan@fad.com', '3');
INSERT INTO `tbl_donatur` (`id`, `nama`, `alamat`, `hp`, `email`, `id_kategori_penyedia_dana`) VALUES ('3', 'Indowebit', 'Malang', '123', 'rus@ti.com', '2');


#
# TABLE STRUCTURE FOR: tbl_kategori_dana
#

DROP TABLE IF EXISTS `tbl_kategori_dana`;

CREATE TABLE `tbl_kategori_dana` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kategori_dana` varchar(50) NOT NULL,
  `keterangan` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_kategori_dana` (`id`, `kategori_dana`, `keterangan`) VALUES ('1', 'Pemerintah', 'ADD');
INSERT INTO `tbl_kategori_dana` (`id`, `kategori_dana`, `keterangan`) VALUES ('2', 'Swasta1', 'Hibah1');


#
# TABLE STRUCTURE FOR: tbl_kategori_penyedia_dana
#

DROP TABLE IF EXISTS `tbl_kategori_penyedia_dana`;

CREATE TABLE `tbl_kategori_penyedia_dana` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kategori_penyedia` varchar(50) NOT NULL,
  `keterangan` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_kategori_penyedia_dana` (`id`, `kategori_penyedia`, `keterangan`) VALUES ('1', 'Pemda Propinsi', 'ADD');
INSERT INTO `tbl_kategori_penyedia_dana` (`id`, `kategori_penyedia`, `keterangan`) VALUES ('2', 'Pemkab Maros', '--');


#
# TABLE STRUCTURE FOR: tbl_menu
#

DROP TABLE IF EXISTS `tbl_menu`;

CREATE TABLE `tbl_menu` (
  `id_menu` int(11) NOT NULL AUTO_INCREMENT,
  `nama_menu` varchar(50) NOT NULL,
  `icon` varchar(40) NOT NULL,
  `link` varchar(30) NOT NULL,
  `parent` int(11) NOT NULL,
  `aktif` enum('Y','N') NOT NULL,
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('1', '  Dashboard', 'fa fa-dashboard', 'welcome', '0', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('2', 'Master', 'fa fa-suitcase', '#', '0', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('6', 'Organisasi', 'fa fa-circle-o text-aqua', 'upload', '2', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('12', 'Transaksi', 'fa fa-th-list', '#', '0', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('22', 'Seting', 'fa fa-gears', '#', '0', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('23', 'Menu seting', 'fa  fa-bars text-aqua', 'menu', '22', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('24', 'User Seting', 'fa fa-circle-o text-aqua', 'pengguna', '22', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('28', 'Donatur', 'fa fa-circle-o text-aqua', 'donatur', '2', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('30', 'Kategori Dana', 'fa fa-circle-o text-aqua', 'kategori_dana', '2', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('31', 'Rekening Bank', 'fa fa-circle-o text-aqua', '#', '2', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('32', 'Akun', 'fa fa-credit-card', '#', '0', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('33', 'Tipe Akun', 'fa fa-circle-o text-aqua', 'tipeakun', '32', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('34', 'Akun ( COA )', 'fa fa-circle-o text-aqua', 'akun', '32', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('35', 'Penyaluran Dana', 'fa fa-circle-o text-aqua', '#', '12', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('36', 'Anggaran', 'fa fa-circle-o text-aqua', '#', '12', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('37', 'Aset Tetap', 'fa fa-circle-o text-aqua', '#', '12', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('38', 'Penyedia', 'fa fa-circle-o text-aqua', '#', '12', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('39', 'Jurnal', 'fa fa-circle-o text-aqua', 'jurnal', '12', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('40', 'Tutup Buku', 'fa fa-circle-o text-aqua', 'tutupbuku', '12', 'Y');
INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `icon`, `link`, `parent`, `aktif`) VALUES ('41', 'Backup Database', 'fa fa-circle-o text-aqua', 'database_backup', '22', 'Y');


#
# TABLE STRUCTURE FOR: tbl_organisasi
#

DROP TABLE IF EXISTS `tbl_organisasi`;

CREATE TABLE `tbl_organisasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_organisasi` varchar(50) NOT NULL,
  `alamat` varchar(250) NOT NULL,
  `hp` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `npwp` varchar(50) NOT NULL,
  `no_wa` varchar(50) NOT NULL,
  `logo_organisasi` varchar(50) NOT NULL,
  `summary_organisasi` varchar(250) NOT NULL,
  `nama_pimpinan` varchar(150) NOT NULL,
  `pimpinan_harian` varchar(150) NOT NULL,
  `id_provinsi` int(11) DEFAULT NULL,
  `id_kabupaten` int(11) DEFAULT NULL,
  `level_organisasi` enum('Pusat','Cabang') NOT NULL,
  `induk_organisasi` int(11) NOT NULL DEFAULT '0',
  `nm_gbr` varchar(50) NOT NULL,
  `tipe_gbr` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_organisasi` (`id`, `nama_organisasi`, `alamat`, `hp`, `email`, `npwp`, `no_wa`, `logo_organisasi`, `summary_organisasi`, `nama_pimpinan`, `pimpinan_harian`, `id_provinsi`, `id_kabupaten`, `level_organisasi`, `induk_organisasi`, `nm_gbr`, `tipe_gbr`) VALUES ('1', 'Jogjaide', 'Jl. Pengayoman Makassar', '89000', 'an@tree.com', '45', '089888', '', 'Healthy Gov', 'Marno', 'Tulus', '25', '399', 'Pusat', '0', 'file_1500455654.jpg', 'image/jpeg');
INSERT INTO `tbl_organisasi` (`id`, `nama_organisasi`, `alamat`, `hp`, `email`, `npwp`, `no_wa`, `logo_organisasi`, `summary_organisasi`, `nama_pimpinan`, `pimpinan_harian`, `id_provinsi`, `id_kabupaten`, `level_organisasi`, `induk_organisasi`, `nm_gbr`, `tipe_gbr`) VALUES ('2', 'PKPD', 'Nusa', '234', 'jjo@hor.sip', '34239', '081232122', '', 'Good', 'Oki', 'Lurah', '13', '196', 'Cabang', '1', 'file_1500456240.png', 'image/png');


#
# TABLE STRUCTURE FOR: tbl_pegawai
#

DROP TABLE IF EXISTS `tbl_pegawai`;

CREATE TABLE `tbl_pegawai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nip` varchar(20) NOT NULL,
  `nama_pegawai` varchar(50) NOT NULL,
  `npwp` varchar(50) NOT NULL,
  `no_ktp` varchar(50) NOT NULL,
  `no_rekening` varchar(50) NOT NULL,
  `alamat` varchar(250) NOT NULL,
  `hp` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `total_gaji` int(11) NOT NULL,
  `total_tunjangan` int(11) NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  `foto_profil` varchar(50) NOT NULL,
  `nm_gbr` varchar(50) NOT NULL,
  `tipe_gbr` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_pegawai` (`id`, `nip`, `nama_pegawai`, `npwp`, `no_ktp`, `no_rekening`, `alamat`, `hp`, `email`, `total_gaji`, `total_tunjangan`, `jabatan`, `foto_profil`, `nm_gbr`, `tipe_gbr`) VALUES ('1', '44', 'Nanang', '33', '', '', 'Pengayoman Makassar', '11', '22', '0', '0', '', '', 'file_1500513719.jpg', 'image/jpeg');
INSERT INTO `tbl_pegawai` (`id`, `nip`, `nama_pegawai`, `npwp`, `no_ktp`, `no_rekening`, `alamat`, `hp`, `email`, `total_gaji`, `total_tunjangan`, `jabatan`, `foto_profil`, `nm_gbr`, `tipe_gbr`) VALUES ('2', '1239', 'Nanang 2', '01230', '', '', 'Antoiku', '01232', 'nan@sdf.com', '0', '0', '', '', 'file_1500514265.jpg', 'image/jpeg');
INSERT INTO `tbl_pegawai` (`id`, `nip`, `nama_pegawai`, `npwp`, `no_ktp`, `no_rekening`, `alamat`, `hp`, `email`, `total_gaji`, `total_tunjangan`, `jabatan`, `foto_profil`, `nm_gbr`, `tipe_gbr`) VALUES ('3', '5', 'No Name', '45', '6', '7', '1', '2', '3', '80', '90', '22222', '', 'file_1500514812.jpg', 'image/jpeg');


#
# TABLE STRUCTURE FOR: tbl_pinjaman_pegawai
#

DROP TABLE IF EXISTS `tbl_pinjaman_pegawai`;

CREATE TABLE `tbl_pinjaman_pegawai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pegawai` int(11) NOT NULL DEFAULT '0',
  `tanggal_pinjaman` date DEFAULT NULL,
  `status_pinjaman` varchar(50) DEFAULT NULL,
  `jumlah_pinjaman` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_pinjaman_pegawai` (`id`, `id_pegawai`, `tanggal_pinjaman`, `status_pinjaman`, `jumlah_pinjaman`) VALUES ('1', '3', '2017-07-22', '3', '1100000');
INSERT INTO `tbl_pinjaman_pegawai` (`id`, `id_pegawai`, `tanggal_pinjaman`, `status_pinjaman`, `jumlah_pinjaman`) VALUES ('2', '2', '2017-03-20', 'ok', '2000000');


#
# TABLE STRUCTURE FOR: tbl_program
#

DROP TABLE IF EXISTS `tbl_program`;

CREATE TABLE `tbl_program` (
  `id_program` int(11) NOT NULL AUTO_INCREMENT,
  `no_program` varchar(40) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `tgl_dibuat` date NOT NULL,
  `yang_buat` int(11) NOT NULL,
  `dikonfirmasi` varchar(10) NOT NULL,
  `kode_unik` varchar(20) NOT NULL,
  `dikonfirmasi_oleh` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  PRIMARY KEY (`id_program`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_program` (`id_program`, `no_program`, `keterangan`, `tgl_dibuat`, `yang_buat`, `dikonfirmasi`, `kode_unik`, `dikonfirmasi_oleh`, `company_id`) VALUES ('7', 'AP-201707-00001', 'test', '2017-07-23', '0', 'Yes', '20c7edjcudes', '0', '1');
INSERT INTO `tbl_program` (`id_program`, `no_program`, `keterangan`, `tgl_dibuat`, `yang_buat`, `dikonfirmasi`, `kode_unik`, `dikonfirmasi_oleh`, `company_id`) VALUES ('8', 'AP-201707-00002', 'testing', '2017-07-23', '0', 'Yes', 'gk5rl3u5pu0', '0', '1');


#
# TABLE STRUCTURE FOR: tbl_program_detail
#

DROP TABLE IF EXISTS `tbl_program_detail`;

CREATE TABLE `tbl_program_detail` (
  `id_program_detail` int(11) NOT NULL AUTO_INCREMENT,
  `id_program` int(11) NOT NULL,
  `id_akun` int(11) NOT NULL,
  `tgl_perencaana` date NOT NULL,
  `uraian` varchar(100) NOT NULL,
  `budget` float DEFAULT NULL,
  `total_penerimaan` float DEFAULT NULL,
  PRIMARY KEY (`id_program_detail`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_program_detail` (`id_program_detail`, `id_program`, `id_akun`, `tgl_perencaana`, `uraian`, `budget`, `total_penerimaan`) VALUES ('5', '7', '0', '0000-00-00', 'test', '100000', '0');
INSERT INTO `tbl_program_detail` (`id_program_detail`, `id_program`, `id_akun`, `tgl_perencaana`, `uraian`, `budget`, `total_penerimaan`) VALUES ('6', '8', '0', '2017-07-23', 'testing', '124566000', '333333');
INSERT INTO `tbl_program_detail` (`id_program_detail`, `id_program`, `id_akun`, `tgl_perencaana`, `uraian`, `budget`, `total_penerimaan`) VALUES ('7', '8', '0', '2017-07-23', 'testing', '11232', '1222');


#
# TABLE STRUCTURE FOR: trs_jurnal
#

DROP TABLE IF EXISTS `trs_jurnal`;

CREATE TABLE `trs_jurnal` (
  `id_jurnal` bigint(20) NOT NULL AUTO_INCREMENT,
  `no_jurnal` varchar(40) NOT NULL,
  `no_bukti` varchar(40) DEFAULT NULL,
  `memo` varchar(160) DEFAULT NULL,
  `tgl_jurnal` date NOT NULL,
  `total` float NOT NULL,
  `dikonfirmasi` varchar(5) NOT NULL,
  `yang_buat` int(11) NOT NULL,
  `tgl_dibuat` datetime NOT NULL,
  `yang_ubah` int(11) DEFAULT NULL,
  `tgl_diubah` datetime DEFAULT NULL,
  `jenis_jurnal` varchar(5) DEFAULT NULL,
  `kode_unik` varchar(20) NOT NULL,
  `dikonfirmasi_oleh` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  PRIMARY KEY (`id_jurnal`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `trs_jurnal` (`id_jurnal`, `no_jurnal`, `no_bukti`, `memo`, `tgl_jurnal`, `total`, `dikonfirmasi`, `yang_buat`, `tgl_dibuat`, `yang_ubah`, `tgl_diubah`, `jenis_jurnal`, `kode_unik`, `dikonfirmasi_oleh`, `company_id`) VALUES ('1', '29-40-333', '29-0003-21', 'Ngetest woyyyy', '2017-04-02', '1000', 'Yes', '0', '2017-04-02 13:54:28', '-1', '2017-07-17 01:34:22', 'JU', '5od0hva3hxs8', '0', '1');
INSERT INTO `trs_jurnal` (`id_jurnal`, `no_jurnal`, `no_bukti`, `memo`, `tgl_jurnal`, `total`, `dikonfirmasi`, `yang_buat`, `tgl_dibuat`, `yang_ubah`, `tgl_diubah`, `jenis_jurnal`, `kode_unik`, `dikonfirmasi_oleh`, `company_id`) VALUES ('2', 'JL-201707-00001', '29-00-32', 'Testing 12345', '2017-07-17', '11', 'Yes', '0', '2017-07-17 01:26:07', '-1', '2017-07-17 01:33:40', 'JU', '4ns47dw0pb8k', '0', '1');
INSERT INTO `trs_jurnal` (`id_jurnal`, `no_jurnal`, `no_bukti`, `memo`, `tgl_jurnal`, `total`, `dikonfirmasi`, `yang_buat`, `tgl_dibuat`, `yang_ubah`, `tgl_diubah`, `jenis_jurnal`, `kode_unik`, `dikonfirmasi_oleh`, `company_id`) VALUES ('3', 'JL-201707-00002', '29-04-92', 'Ini pembayaran Listrik ', '2017-07-17', '1000', 'Yes', '0', '2017-07-17 01:32:20', NULL, NULL, 'JU', '16zg7sl43ew0', '0', '1');


#
# TABLE STRUCTURE FOR: trs_jurnal_detail
#

DROP TABLE IF EXISTS `trs_jurnal_detail`;

CREATE TABLE `trs_jurnal_detail` (
  `id_jurnal_detail` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_jurnal` bigint(20) NOT NULL,
  `id_akun` int(11) NOT NULL,
  `uraian` varchar(160) DEFAULT NULL,
  `amount` float NOT NULL,
  `debet` float NOT NULL,
  `kredit` float NOT NULL,
  PRIMARY KEY (`id_jurnal_detail`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `trs_jurnal_detail` (`id_jurnal_detail`, `id_jurnal`, `id_akun`, `uraian`, `amount`, `debet`, `kredit`) VALUES ('5', '3', '1', 'Ini pembayaran Listrik ', '1000', '1000', '0');
INSERT INTO `trs_jurnal_detail` (`id_jurnal_detail`, `id_jurnal`, `id_akun`, `uraian`, `amount`, `debet`, `kredit`) VALUES ('6', '3', '1', 'Ini pembayaran Listrik ', '-1000', '0', '1000');
INSERT INTO `trs_jurnal_detail` (`id_jurnal_detail`, `id_jurnal`, `id_akun`, `uraian`, `amount`, `debet`, `kredit`) VALUES ('9', '2', '9', 'Test 1', '11', '11', '0');
INSERT INTO `trs_jurnal_detail` (`id_jurnal_detail`, `id_jurnal`, `id_akun`, `uraian`, `amount`, `debet`, `kredit`) VALUES ('10', '2', '9', 'Test 1', '-11', '0', '11');
INSERT INTO `trs_jurnal_detail` (`id_jurnal_detail`, `id_jurnal`, `id_akun`, `uraian`, `amount`, `debet`, `kredit`) VALUES ('11', '1', '1', 'pembayaran biaya listrik', '1000', '1000', '0');
INSERT INTO `trs_jurnal_detail` (`id_jurnal_detail`, `id_jurnal`, `id_akun`, `uraian`, `amount`, `debet`, `kredit`) VALUES ('12', '1', '9', 'pembayaran biaya listrik', '-1000', '0', '1000');


#
# TABLE STRUCTURE FOR: trs_laba_rugi
#

DROP TABLE IF EXISTS `trs_laba_rugi`;

CREATE TABLE `trs_laba_rugi` (
  `id_laba_rugi` bigint(20) NOT NULL AUTO_INCREMENT,
  `periode_laba_rugi` date NOT NULL,
  `laba_rugi` float NOT NULL,
  `company_id` int(11) NOT NULL,
  PRIMARY KEY (`id_laba_rugi`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `trs_laba_rugi` (`id_laba_rugi`, `periode_laba_rugi`, `laba_rugi`, `company_id`) VALUES ('1', '2017-02-01', '0', '1');
INSERT INTO `trs_laba_rugi` (`id_laba_rugi`, `periode_laba_rugi`, `laba_rugi`, `company_id`) VALUES ('2', '2017-03-01', '90000', '1');
INSERT INTO `trs_laba_rugi` (`id_laba_rugi`, `periode_laba_rugi`, `laba_rugi`, `company_id`) VALUES ('3', '2017-03-01', '0', '0');
INSERT INTO `trs_laba_rugi` (`id_laba_rugi`, `periode_laba_rugi`, `laba_rugi`, `company_id`) VALUES ('4', '2017-05-01', '0', '1');
INSERT INTO `trs_laba_rugi` (`id_laba_rugi`, `periode_laba_rugi`, `laba_rugi`, `company_id`) VALUES ('5', '2017-06-01', '0', '1');


#
# TABLE STRUCTURE FOR: trs_neraca_saldo
#

DROP TABLE IF EXISTS `trs_neraca_saldo`;

CREATE TABLE `trs_neraca_saldo` (
  `id_neraca_saldo` bigint(20) NOT NULL AUTO_INCREMENT,
  `periode_neraca_saldo` date NOT NULL,
  `id_akun` int(11) NOT NULL,
  `amount` float NOT NULL,
  `debet` float NOT NULL,
  `kredit` float NOT NULL,
  `company_id` int(11) NOT NULL,
  PRIMARY KEY (`id_neraca_saldo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: trs_neraca_saldo_tmp
#

DROP TABLE IF EXISTS `trs_neraca_saldo_tmp`;

CREATE TABLE `trs_neraca_saldo_tmp` (
  `id_neraca_saldo` bigint(20) NOT NULL AUTO_INCREMENT,
  `periode_neraca_saldo` date NOT NULL,
  `id_akun` int(11) NOT NULL,
  `amount` float NOT NULL,
  `debet` float NOT NULL,
  `kredit` float NOT NULL,
  `company_id` int(11) NOT NULL,
  PRIMARY KEY (`id_neraca_saldo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: trs_tutup_buku_bulanan
#

DROP TABLE IF EXISTS `trs_tutup_buku_bulanan`;

CREATE TABLE `trs_tutup_buku_bulanan` (
  `id_tb_bulanan` int(11) NOT NULL AUTO_INCREMENT,
  `periode_tb_bulanan` date NOT NULL,
  `yang_buat` int(11) NOT NULL,
  `tgl_dibuat` datetime NOT NULL,
  `company_id` int(11) NOT NULL,
  `kode_unik` varchar(10) NOT NULL,
  `status` varchar(1) NOT NULL,
  `id_batalkan` bigint(20) NOT NULL,
  PRIMARY KEY (`id_tb_bulanan`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `trs_tutup_buku_bulanan` (`id_tb_bulanan`, `periode_tb_bulanan`, `yang_buat`, `tgl_dibuat`, `company_id`, `kode_unik`, `status`, `id_batalkan`) VALUES ('1', '2017-02-01', '1', '2017-03-07 14:38:08', '1', '71lvlq6ta9', 'N', '1');
INSERT INTO `trs_tutup_buku_bulanan` (`id_tb_bulanan`, `periode_tb_bulanan`, `yang_buat`, `tgl_dibuat`, `company_id`, `kode_unik`, `status`, `id_batalkan`) VALUES ('2', '2017-03-01', '1', '2017-03-21 16:09:46', '1', '1so6j3492n', 'N', '1');
INSERT INTO `trs_tutup_buku_bulanan` (`id_tb_bulanan`, `periode_tb_bulanan`, `yang_buat`, `tgl_dibuat`, `company_id`, `kode_unik`, `status`, `id_batalkan`) VALUES ('3', '2017-03-01', '1', '2017-03-21 16:11:51', '1', 'hkabgfkzpz', 'N', '1');
INSERT INTO `trs_tutup_buku_bulanan` (`id_tb_bulanan`, `periode_tb_bulanan`, `yang_buat`, `tgl_dibuat`, `company_id`, `kode_unik`, `status`, `id_batalkan`) VALUES ('4', '2017-03-01', '1', '2017-03-21 16:21:17', '1', '1uy2ns66hx', 'N', '1');
INSERT INTO `trs_tutup_buku_bulanan` (`id_tb_bulanan`, `periode_tb_bulanan`, `yang_buat`, `tgl_dibuat`, `company_id`, `kode_unik`, `status`, `id_batalkan`) VALUES ('5', '2017-06-01', '4', '2017-06-05 16:44:36', '1', '4ezkoukjb3', 'N', '4');
INSERT INTO `trs_tutup_buku_bulanan` (`id_tb_bulanan`, `periode_tb_bulanan`, `yang_buat`, `tgl_dibuat`, `company_id`, `kode_unik`, `status`, `id_batalkan`) VALUES ('6', '2017-06-01', '4', '2017-06-05 16:46:40', '1', '61l0nqw3iw', 'N', '4');


